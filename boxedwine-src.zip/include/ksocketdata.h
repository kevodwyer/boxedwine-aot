#ifndef __KSOCKETDATA_H__
#define __KSOCKETDATA_H__

#include "ksocketmsg.h"



class KSocketData {
public:
    
};

#endif