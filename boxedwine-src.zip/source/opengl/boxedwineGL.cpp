#include "boxedwine.h"
#include "boxedwineGL.h"

BoxedwineGL* BoxedwineGL::current;