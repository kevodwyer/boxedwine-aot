#ifndef __SPINNER_CONTROL_H__
#define __SPINNER_CONTROL_H__

namespace ImGui {
	void Spinner(const char* label);
    float GetSpinnerWidth();
}
#endif