#ifndef __UI_SETTINGS_H__
#define __UI_SETTINGS_H__

class UiSettings {
public:
    static int MAX_NUMBER_OF_LINES_FOR_APP_LIST_VIEW_TEXT;
    static int ICON_SIZE;
};
#endif