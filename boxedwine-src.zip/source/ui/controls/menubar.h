#ifndef __MENUBAR_H__
#define __MENUBAR_H__

void uiShowAppMenuBar();

#endif