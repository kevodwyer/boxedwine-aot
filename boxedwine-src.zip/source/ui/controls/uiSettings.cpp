#include "boxedwine.h"
#include "../boxedwineui.h"
#include "uiSettings.h"

int UiSettings::MAX_NUMBER_OF_LINES_FOR_APP_LIST_VIEW_TEXT = 3;
int UiSettings::ICON_SIZE = 48;