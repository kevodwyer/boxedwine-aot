#ifndef __READ_ICONS_H__
#define __READ_ICONS_H__

const unsigned char* extractIconFromExe(const std::string& nativeExePath, int size, int* width, int* height);

#endif