#ifndef __MAINLOOP_H__
#define __MAINLOOP_H__

bool doMainLoop();

#endif