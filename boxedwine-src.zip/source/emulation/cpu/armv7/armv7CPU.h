#ifndef __ARMV7CPU_H__
#define __ARMV7CPU_H__

#ifdef BOXEDWINE_DYNAMIC_ARMV7
void OPCALL firstDynamicOp(CPU* cpu, DecodedOp* op);
#endif

#endif