#ifndef __LVM_HELPER_H__
#define __LVM_HELPER_H__

bool processLogicalImmediate(U64 Imm, U32 RegSize, U64& Encoding);

#endif