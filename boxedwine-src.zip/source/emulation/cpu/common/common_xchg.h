void common_cmpxchgr8r8(CPU* cpu, U32 dstReg, U32 srcReg);
void common_cmpxchge8r8(CPU* cpu, U32 address, U32 srcReg);
void common_cmpxchgr16r16(CPU* cpu, U32 dstReg, U32 srcReg);
void common_cmpxchge16r16(CPU* cpu, U32 address, U32 srcReg);
void common_cmpxchgr32r32(CPU* cpu, U32 dstReg, U32 srcReg);
void common_cmpxchge32r32(CPU* cpu, U32 address, U32 srcReg);
