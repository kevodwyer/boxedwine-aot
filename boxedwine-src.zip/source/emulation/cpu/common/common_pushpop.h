void common_pushA32(CPU* cpu);
void common_pushA16(CPU* cpu);
void common_popA32(CPU* cpu);
void common_popA16(CPU* cpu);
